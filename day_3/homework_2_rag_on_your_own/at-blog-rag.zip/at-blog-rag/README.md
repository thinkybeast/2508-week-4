# Appalachian Trail Blog RAG Assistant

This project creates a Retrieval-Augmented Generation (RAG) system that allows users to ask questions about my Appalachian Trail thru-hike experience. The system uses blog entries from my hike, stored in a PostgreSQL database with vector embeddings, to provide context-aware responses to user queries.

## Prerequisites

- Python 3.8+
- PostgreSQL 12+ with pgvector extension
- OpenAI API key

## Installation

1. Unzip the project directory:
```bash
unzip at-blog-rag.zip
cd at-blog-rag
```

2. Create and activate a virtual environment:
```bash
python -m venv venv
source venv/bin/activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Set up PostgreSQL:
   - Install PostgreSQL if you haven't already
   - Install the pgvector extension:
     ```sql
     CREATE EXTENSION vector;
     ```
   - Create a database named `thruhike_blog`

5. Replace the 'your_api_key_here' in `.env` with your OpenAI API key:
```
OPENAI_API_KEY=your_api_key_here
```

## Data Processing

Before using the system, you need to process the blog entries by running the `pre_processing.py` script:

```bash
python src/pre_processing.py
```

This will:
- Read the CSV file
- Generate embeddings for each entry
- Store the data in the PostgreSQL database

## Running the Application

### Option 1: Web Interface

Run the Gradio interface for a user-friendly web experience:
```bash
python src/main_gradio_interface.py
```

This will:
- Start a local web server
- Open the interface in your default browser
- Allow you to:
  - Ask questions about my hike
  - Get random question suggestions
  - See responses with source attribution

### Option 2: Command Line Interface

Run the CLI version for a simpler interface:
```bash
python src/main_command_line.py
```

This provides:
- A text-based interface
- Same functionality as the web version
- Responses in the terminal

## Project Structure

```
at-blog-rag/
├── data/
│   └── at_map_points.csv    # Blog entries data
├── src/
│   ├── pre_processing.py    # Data processing and embedding generation
│   ├── rag_tools.py        # Shared RAG functionality
│   ├── main_command_line.py # CLI interface
│   └── main_gradio_interface.py # Web interface
├── requirements.txt        # Python dependencies
└── README.md
```

## Database Schema

The `blog_entries` table contains:
- `id`: Unique identifier
- `latitude`: Location latitude
- `longitude`: Location longitude
- `title`: Entry title
- `blog_text`: Full blog entry text
- `embedding`: Vector embedding of the blog text