import os
import pandas as pd
import psycopg2
from psycopg2.extras import execute_values
from dotenv import load_dotenv
from openai import OpenAI
import numpy as np
import re
import csv

# Load environment variables
load_dotenv()

# Initialize OpenAI client
client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

def get_db_connection():
    """Create a connection to the PostgreSQL database."""
    return psycopg2.connect(
        dbname="thruhike_blog",
        user="postgres",
        host="localhost",
        port='5432',
    )

def create_tables(conn):
    """Create necessary tables if they don't exist."""
    with conn.cursor() as cur:
        # Create the vector extension if it doesn't exist
        cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")
        
        # Create the blog entries table
        cur.execute("""
            CREATE TABLE IF NOT EXISTS blog_entries (
                id SERIAL PRIMARY KEY,
                latitude FLOAT,
                longitude FLOAT,
                title TEXT,
                blog_text TEXT,
                embedding vector(1536)
            );
        """)
    conn.commit()

def extract_coordinates(wkt_point):
    """Extract latitude and longitude from WKT POINT format."""
    # WKT format is "POINT (longitude latitude)"
    match = re.search(r'POINT \(([-\d.]+) ([-\d.]+)\)', wkt_point)
    if match:
        longitude = float(match.group(1))
        latitude = float(match.group(2))
        return latitude, longitude
    return None, None

def generate_embedding(text):
    print('generating embedding')
    """Generate embedding for the given text using OpenAI's API."""
    if not text or pd.isna(text):
        print("Warning: No blog text - skipping entry")
        return None
    try:
        response = client.embeddings.create(
            model="text-embedding-3-small",
            input=text
        )
        return response.data[0].embedding
    except Exception as e:
        print(f"Error generating embedding: {str(e)}")
        print(f"Text that failed: {text[:200]}...")  # Print first 200 chars of the text
        return None

def process_csv_and_store():
    """Process the CSV file and store data in the database."""
    print("Starting to process CSV file...")
    data_rows = []
    csv_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'at_map_points.csv')
    print(f"Reading CSV from: {csv_path}")
    
    with open(csv_path, 'r', encoding='utf-8') as csvfile:
        # Create CSV reader
        csv_reader = csv.reader(csvfile, quotechar='"', delimiter=',')
        
        # Skip the header row
        next(csv_reader)
        
        # Process each row
        for row in csv_reader:
            if len(row) == 3:
                wkt = row[0]
                title = row[1]
                blog_text = row[2]
                
                data_rows.append({
                    'WKT': wkt,
                    'title': title,
                    'blog_text': blog_text
                })

    print(f"Found {len(data_rows)} entries in CSV")
    # Create DataFrame from parsed data
    df = pd.DataFrame(data_rows)
    
    # Connect to the database
    print("Connecting to database...")
    conn = get_db_connection()
    
    try:
        # Create tables
        print("Creating tables...")
        create_tables(conn)
        
        # Process each row
        print("Processing rows and generating embeddings...")
        with conn.cursor() as cur:
            for idx, row in df.iterrows():
                print(f"\nProcessing row {idx + 1}:")
                # Extract coordinates from WKT
                latitude, longitude = extract_coordinates(row['WKT'])
                if latitude is None or longitude is None:
                    print(f"Warning: Could not extract coordinates from {row['WKT']}")
                    continue
                
                print(f"Coordinates extracted: {latitude}, {longitude}")
                print(f"Description to embed: {row['blog_text'][:50]}...")
                
                # Generate embedding for the description
                embedding = generate_embedding(row['blog_text'])
                if embedding is None:
                    print("Warning: Could not generate embedding")
                    continue
                
                print("Embedding generated successfully")
                
                # Insert the data
                cur.execute("""
                    INSERT INTO blog_entries (latitude, longitude, title, blog_text, embedding)
                    VALUES (%s, %s, %s, %s, %s)
                """, (
                    latitude,
                    longitude,
                    row['title'],
                    row['blog_text'],
                    embedding
                ))
                
                # Print progress message
                preview = row['blog_text'][:100] + "..." if len(row['blog_text']) > 100 else row['blog_text']
                print(f"Successfully stored embedding for '{row['title']}': {preview}")
        
        conn.commit()
        print("\nSuccessfully processed and stored all blog entries.")
        
    except Exception as e:
        print(f"An error occurred: {e}")
        conn.rollback()
    finally:
        conn.close()

if __name__ == "__main__":
    process_csv_and_store() 