import os
import psycopg2
from dotenv import load_dotenv
from openai import OpenAI

# Load environment variables
load_dotenv()

# Initialize OpenAI client
client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

def get_db_connection():
    """Create a connection to the PostgreSQL database."""
    return psycopg2.connect(
        dbname="thruhike_blog",
        user="postgres",
        host="localhost",
        port='5432',
    )

def generate_embedding(text):
    """Generate embedding for the given text using OpenAI's API."""
    if not text:
        print("Warning: No blog text - skipping entry")
        return None
    try:
        response = client.embeddings.create(
            model="text-embedding-3-small",
            input=text
        )
        return response.data[0].embedding
    except Exception as e:
        print(f"Error generating embedding: {str(e)}")
        print(f"Text that failed: {text[:200]}...")
        return None

def search_similar_entries(query, limit=5):
    """Search for similar blog entries based on the query."""
    # Generate embedding for the query
    query_embedding = generate_embedding(query)
    
    # Connect to the database
    conn = get_db_connection()
    
    try:
        with conn.cursor() as cur:
            # Perform the similarity search
            cur.execute("""
                SELECT 
                    title,
                    blog_text,
                    latitude,
                    longitude,
                    1 - (embedding <=> %s::vector) as similarity
                FROM blog_entries
                ORDER BY embedding <=> %s::vector
                LIMIT %s
            """, (query_embedding, query_embedding, limit))
            
            results = cur.fetchall()
            
            # Format the results
            formatted_results = []
            for row in results:
                formatted_results.append({
                    'title': row[0],
                    'blog_text': row[1],
                    'latitude': row[2],
                    'longitude': row[3],
                    'similarity': row[4]
                })
            
            return formatted_results
            
    finally:
        conn.close()

def format_rag_prompt(relevant_entries):
    """Format the RAG prompt with context and question."""
    # Start with system instructions
    prompt = "You are a storyteller sharing the journey of my Appalachian Trail thru-hike. Use the provided blog entries from my hike to answer the user's questions as if you're recounting the story of my adventure from my perspective. If the entries aren't relevant to the question, feel free to say that you aren't sure about that question. The responses shouldn't be very long, a paragraph or two. Blog entries signed by 'B' are made by me, Brandi, and 'O' is Olivier, my partner. Our trail names were 'Skipper' (Brandi) and 'Potato' (Olivier). Please provide an engaging response that reflects the experiences, challenges, and memorable moments from my hike. Tell your responses from a first-person perspective."

    # Add the relevant blog entries as context
    prompt += "\n\nRelevant blog entries:\n"
    for entry in relevant_entries:
        prompt += f"\nLocation: {entry['title']} ({entry['latitude']}, {entry['longitude']})\n"
        prompt += f"Content: {entry['blog_text']}\n"

    return prompt

def get_llm_response(prompt, question):
    """Get response from OpenAI's API."""
    response = client.responses.create(
        model="gpt-3.5-turbo",
        input=[
            { "role": "developer", "content": prompt },
            { "role": "user", "content": question }
        ],
    )
    return response.output_text

def generate_random_question():
    """Generate a random question about the Appalachian Trail."""
    prompt = """Generate an interesting question about the Appalachian Trail that someone might ask a thru-hiker. Choose a random topics from this list:
- Trail routines and daily life
- Food and eating habits
- Physical transformation
- Sleep and shelter setup
- Gear choices and ultralight strategies
- Mental toughness and burnout
- Injuries and recovery
- Dealing with weather extremes
- Navigating the trail
- Resupplying and town stops
- Cost and budgeting
- Trail culture and community
- Trail names and nicknames
- Wildlife encounters
- Loneliness and connection
- Memorable trail moments
- Lessons learned
- Reintegrating into normal life
- Personal growth
- Advice for future hikers

The question should be specific and about moments on the trail, not about feelings and over-arching takeaways. Make it engaging and natural, as if a friend is asking about your hike. Keep it to one or two sentences."""

    response = client.responses.create(
        model="gpt-4o-mini",
        input=[
            { "role": "user", "content": prompt }
        ],
        temperature=1.3,
    )
    return response.output_text

def process_query(question):
    """Process a query and return the response with sources."""
    if not question.strip():
        return "Please enter a question about the Appalachian Trail."
    
    # Search for relevant entries
    relevant_entries = search_similar_entries(question, limit=3)
    
    if not relevant_entries:
        return "I couldn't find any relevant blog entries for your question."
    
    # Format the RAG prompt
    prompt = format_rag_prompt(relevant_entries)
    
    # Get the response
    response = get_llm_response(prompt, question)
    
    # Format sources
    sources = "\n\nSources:\n" + "\n".join([
        f"- {entry['title']} (Similarity: {entry['similarity']:.2f})"
        for entry in relevant_entries
    ])
    
    return response + sources 