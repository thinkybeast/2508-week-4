from rag_tools import process_query

def main():
    """Main function to run the RAG application."""
    print("\nWelcome to my Appalachian Trail Blog Experience!")
    print("You can ask questions about my 6 month hike from Georgia to Maine.")
    print("Type 'quit' at any time to exit.\n")

    while True:
        # Get user question
        question = input("\nWhat would you like to know about? ")
        
        if question.lower() == 'quit':
            print("\nThanks for using the AT Blog Assistant. Happy trails!")
            break
        
        # Process the query and display response
        response = process_query(question)
        print("\nResponse:")
        print(response)

if __name__ == "__main__":
    main() 